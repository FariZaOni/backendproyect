package fari.ludica.backend.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/User") //QUE DEMONIOS HACE ESTO???? NO ENTIENDO POR FAVOR PEGUENME UN TIRO COMO SE HACE ESTO QUE CHUCHA ES UN MAPPING
public class userController {
    @Autowired
    private UserRepository userRepo;

    @PostMapping
    public ResponseEntity<?> saveUser(@RequestBody User user){
        try{
            User usersave userRepo.save(User);
            return new ResponseEntity<User>(usersave, HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity<String>(e.getCause().toString(), HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }
    //UPDATE: CREO que entiendo, el requestmapping/postmapping está alerta a cualquier peticion de su puerto???
    //En esta clase se separan las peticiones de Login y Register?
}

