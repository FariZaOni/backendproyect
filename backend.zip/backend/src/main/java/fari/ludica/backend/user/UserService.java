package fari.ludica.backend.user;

public class UserService {

}
