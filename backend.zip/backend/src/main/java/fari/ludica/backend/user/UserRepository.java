package fari.ludica.backend.user;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public interface UserRepository extends MongoRepository<User,Integer> {
    @GetMapping
    public String

}
